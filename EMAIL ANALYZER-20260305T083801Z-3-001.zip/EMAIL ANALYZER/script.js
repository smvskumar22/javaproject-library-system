// Neon Sentinel – Email Threat Analyzer

const $ = (id) => document.getElementById(id);

const rawEmailInput = $("rawEmail");

const analyzeBtn = $("analyzeBtn");
const clearBtn = $("clearBtn");

const classificationBadge = $("classificationBadge");
const scoreBar = $("scoreBar");
const scoreValue = $("scoreValue");
const threatList = $("threatList");
const keywordSummary = $("keywordSummary");
const finalVerdict = $("finalVerdict");
const timestampLabel = $("timestampLabel");

const KEYWORD_GROUPS = {
  urgency: [
    "urgent",
    "immediately",
    "right away",
    "asap",
    "action required",
    "final notice",
  ],
  credentials: [
    "password",
    "login",
    "sign in",
    "verify account",
    "confirm account",
    "security alert",
    "suspended",
  ],
  money: [
    "lottery",
    "prize",
    "winner",
    "jackpot",
    "wire transfer",
    "bank details",
    "bitcoin",
    "crypto",
    "gift card",
    "giftcard",
  ],
  pressure: [
    "do not tell",
    "keep this secret",
    "confidential",
    "limited time",
    "last chance",
  ],
};

const SUSPICIOUS_TLDS = [
  ".xyz",
  ".top",
  ".club",
  ".live",
  ".link",
  ".support",
  ".loan",
  ".win",
  ".bid",
  ".party",
  ".click",
];

const HIGH_RISK_ATTACHMENTS = [
  ".exe",
  ".scr",
  ".bat",
  ".cmd",
  ".vbs",
  ".js",
  ".jar",
  ".apk",
  ".dll",
];

const COMPRESSED_ATTACHMENTS = [".zip", ".rar", ".7z"];

const MACRO_DOCS = [".docm", ".xlsm", ".pptm"];

function extractUrls(text) {
  if (!text) return [];
  const urlRegex =
    /\b((https?:\/\/)?[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?(\/[^\s]*)?)/gi;
  const matches = [];
  let m;
  while ((m = urlRegex.exec(text)) !== null) {
    matches.push(m[0]);
  }
  return [...new Set(matches)];
}

function getDomainFromEmail(email) {
  if (!email || !email.includes("@")) return null;
  return email.split("@")[1].toLowerCase();
}

function hasDisplayNameMismatch(displayName, email) {
  if (!displayName || !email) return false;
  const lowered = displayName.toLowerCase();
  const knownBrands = [
    "microsoft",
    "google",
    "paypal",
    "bank",
    "apple",
    "amazon",
    "netflix",
  ];
  const domain = getDomainFromEmail(email) || "";
  return knownBrands.some(
    (brand) => lowered.includes(brand) && !domain.includes(brand)
  );
}

function scoreKeywords(text) {
  const result = {
    counts: {},
    riskDelta: 0,
    matched: [],
  };
  if (!text) return result;
  const lc = text.toLowerCase();

  Object.entries(KEYWORD_GROUPS).forEach(([group, words]) => {
    let count = 0;
    words.forEach((w) => {
      const re = new RegExp(`\\b${w.replace(/\s+/g, "\\s+")}\\b`, "gi");
      const matches = lc.match(re);
      if (matches) count += matches.length;
    });
    if (count > 0) {
      result.counts[group] = count;
      let delta = 0;
      switch (group) {
        case "urgency":
          delta = 8;
          break;
        case "credentials":
          delta = 15;
          break;
        case "money":
          delta = 12;
          break;
        case "pressure":
          delta = 10;
          break;
        default:
          delta = 5;
      }
      result.riskDelta += delta + Math.min(count - 1, 3) * 2;
      result.matched.push({ group, count });
    }
  });

  return result;
}

function evaluateAttachments(raw) {
  const details = [];
  let risk = 0;
  if (!raw) return { risk, details };

  const files = raw
    .split(",")
    .map((f) => f.trim())
    .filter(Boolean);

  files.forEach((file) => {
    const lower = file.toLowerCase();
    const extMatch = /\.[a-z0-9]+$/.exec(lower);
    const ext = extMatch ? extMatch[0] : "";

    if (HIGH_RISK_ATTACHMENTS.includes(ext)) {
      risk += 25;
      details.push({
        level: "danger",
        message: `High‑risk executable attachment detected (${file}).`,
      });
    } else if (MACRO_DOCS.includes(ext)) {
      risk += 18;
      details.push({
        level: "warn",
        message: `Document type capable of macros detected (${file}).`,
      });
    } else if (COMPRESSED_ATTACHMENTS.includes(ext)) {
      risk += 10;
      details.push({
        level: "warn",
        message: `Compressed archive detected (${file}) – contents not visible.`,
      });
    }
  });

  return { risk, details };
}

function evaluateLinks(body) {
  const urls = extractUrls(body);
  const details = [];
  let risk = 0;

  urls.forEach((url) => {
    const lower = url.toLowerCase();
    if (lower.includes("bit.ly") || lower.includes("tinyurl") || /goo\.gl/.test(lower)) {
      risk += 10;
      details.push({
        level: "warn",
        message: `Shortened or obfuscated link detected (${url}).`,
      });
    }

    const tldMatch = /\.[a-z]{2,}(\/|$)/.exec(lower);
    if (tldMatch) {
      const tld = tldMatch[0].replace("/", "");
      if (SUSPICIOUS_TLDS.includes(tld)) {
        risk += 8;
        details.push({
          level: "warn",
          message: `Link with higher‑risk domain extension detected (${url}).`,
        });
      }
    }

    if (/https?:\/\/\d{1,3}(\.\d{1,3}){3}/.test(lower)) {
      risk += 12;
      details.push({
        level: "danger",
        message: `Link pointing directly to an IP address detected (${url}).`,
      });
    }
  });

  return { risk, details, urls };
}

function evaluateSender(senderEmail, senderDisplay) {
  const details = [];
  let risk = 0;

  if (!senderEmail) {
    details.push({
      level: "warn",
      message: "Sender email address missing – unable to verify origin.",
    });
    risk += 10;
    return { risk, details };
  }

  const domain = getDomainFromEmail(senderEmail);
  if (!domain || !domain.includes(".")) {
    details.push({
      level: "danger",
      message: "Sender domain is malformed or incomplete.",
    });
    risk += 18;
  } else {
    const tld = domain.substring(domain.lastIndexOf("."));
    if (SUSPICIOUS_TLDS.includes(tld)) {
      details.push({
        level: "warn",
        message: `Unusual sender top‑level domain detected (${domain}).`,
      });
      risk += 8;
    }

    if (/@gmail\.com$/.test(senderEmail.toLowerCase()) && senderDisplay) {
      const dispLower = senderDisplay.toLowerCase();
      if (
        dispLower.includes("support") ||
        dispLower.includes("security") ||
        dispLower.includes("billing")
      ) {
        details.push({
          level: "warn",
          message:
            "Generic webmail address used for what appears to be an official support or billing identity.",
        });
        risk += 10;
      }
    }
  }

  if (hasDisplayNameMismatch(senderDisplay, senderEmail)) {
    details.push({
      level: "danger",
      message:
        "Display name suggests a well‑known brand but the domain does not match – potential spoofing.",
    });
    risk += 20;
  }

  return { risk, details };
}

function parseRawEmail(raw) {
  const parsed = {
    senderEmail: "",
    senderDisplay: "",
    subject: "",
    attachments: "",
    body: "",
  };

  if (!raw) return parsed;

  const normalized = raw.replace(/\r\n/g, "\n");
  const sections = normalized.split(/\n\n/);

  let headerBlock = "";
  let bodyBlock = "";

  if (sections.length > 1) {
    headerBlock = sections[0];
    bodyBlock = sections.slice(1).join("\n\n");
  } else {
    bodyBlock = normalized;
  }

  const unfoldedHeaders = headerBlock.replace(/\n[ \t]+/g, " ");

  const fromMatch = unfoldedHeaders.match(/^from:\s*(.+)$/im);
  if (fromMatch) {
    const fromValue = fromMatch[1].trim();
    const angleMatch = fromValue.match(/<([^>]+)>/);
    if (angleMatch) {
      parsed.senderEmail = angleMatch[1].trim();
      parsed.senderDisplay = fromValue
        .replace(angleMatch[0], "")
        .trim()
        .replace(/^"|"$/g, "");
    } else {
      const emailOnly = fromValue.match(/[^\s]+@[^\s]+/);
      if (emailOnly) {
        parsed.senderEmail = emailOnly[0];
        parsed.senderDisplay = fromValue
          .replace(emailOnly[0], "")
          .trim()
          .replace(/^"|"$/g, "");
      }
    }
  }

  const subjectMatch = unfoldedHeaders.match(/^subject:\s*(.+)$/im);
  if (subjectMatch) {
    parsed.subject = subjectMatch[1].trim();
  }

  const attachmentNames = [];
  const filenameRegex = /filename\*?=["']?([^";\r\n]+)["']?/gi;
  let m;
  while ((m = filenameRegex.exec(unfoldedHeaders)) !== null) {
    attachmentNames.push(m[1]);
  }

  const simpleAttachmentRegex = /^attachment:\s*(.+)$/gim;
  let a;
  while ((a = simpleAttachmentRegex.exec(unfoldedHeaders)) !== null) {
    attachmentNames.push(a[1].trim());
  }

  if (attachmentNames.length) {
    parsed.attachments = attachmentNames.join(", ");
  }

  parsed.body = bodyBlock.trim();

  return parsed;
}

function aggregateAnalysis() {
  const raw = rawEmailInput.value.trim();
  const parsed = parseRawEmail(raw);

  const { senderEmail, senderDisplay, subject, attachments, body } = parsed;

  const combinedText = [subject, body].filter(Boolean).join("\n\n");

  let riskScore = 0;
  const threats = [];

  const senderResult = evaluateSender(senderEmail, senderDisplay);
  riskScore += senderResult.risk;
  threats.push(...senderResult.details);

  const attachmentResult = evaluateAttachments(attachments);
  riskScore += attachmentResult.risk;
  threats.push(...attachmentResult.details);

  const linkResult = evaluateLinks(combinedText);
  riskScore += linkResult.risk;
  threats.push(...linkResult.details);

  const keywordResult = scoreKeywords(combinedText);
  riskScore += keywordResult.riskDelta;

  let contentBaseline = 0;
  if (!body) {
    contentBaseline += 10;
    threats.push({
      level: "warn",
      message: "Email body missing or empty – context for verification is low.",
    });
  }
  riskScore += contentBaseline;

  const cappedRisk = Math.min(riskScore, 100);
  const riskPercent = Math.max(0, Math.min(100, Math.round(cappedRisk)));
  const safetyConfidence = Math.max(0, Math.min(100, 100 - riskPercent));

  const isUnsafe = riskPercent >= 40 || safetyConfidence < 70;

  return {
    isUnsafe,
    riskPercent,
    safetyConfidence,
    threats,
    keywordResult,
    linkResult,
    inputs: {
      senderEmail,
      senderDisplay,
      subject,
      attachments,
      body,
    },
  };
}

function renderThreats(threats) {
  threatList.innerHTML = "";
  if (!threats.length) {
    const li = document.createElement("li");
    li.className = "threat-item";
    li.innerHTML =
      '<div class="threat-indicator threat-indicator--safe"></div><div>No significant technical threat signals detected in headers, links, or attachments.</div>';
    threatList.appendChild(li);
    return;
  }

  threats.forEach((t) => {
    const li = document.createElement("li");
    li.className = "threat-item";
    const indicatorClass =
      t.level === "danger"
        ? "threat-indicator--danger"
        : t.level === "warn"
        ? "threat-indicator--warn"
        : "threat-indicator--safe";
    li.innerHTML = `<div class="threat-indicator ${indicatorClass}"></div><div>${t.message}</div>`;
    threatList.appendChild(li);
  });
}

function renderKeywords(keywordResult) {
  const { matched } = keywordResult;
  if (!matched.length) {
    keywordSummary.textContent =
      "No elevated‑risk wording detected. Tone appears typical for a normal business or personal email.";
    return;
  }

  const fragments = [];
  matched.forEach(({ group, count }) => {
    let label;
    switch (group) {
      case "urgency":
        label = "Urgency & time pressure";
        break;
      case "credentials":
        label = "Credentials & account access";
        break;
      case "money":
        label = "Money, prizes, or transfers";
        break;
      case "pressure":
        label = "Secrecy & social pressure";
        break;
      default:
        label = group;
    }
    const chip = document.createElement("span");
    chip.className = "keyword-chip";
    chip.innerHTML = `<strong>${label}</strong><span>x${count}</span>`;
    fragments.push(chip);
  });

  keywordSummary.innerHTML = "";
  fragments.forEach((chip) => keywordSummary.appendChild(chip));
}

function renderVerdict({ isUnsafe, riskPercent, safetyConfidence, inputs, linkResult }) {
  const now = new Date();
  timestampLabel.textContent = `Scan time: ${now
    .toISOString()
    .replace("T", " ")
    .replace(/\.\d+Z$/, "Z")}`;

  scoreBar.style.width = `${riskPercent}%`;
  scoreValue.textContent = `${riskPercent}%`;

  classificationBadge.className = "badge";
  finalVerdict.classList.remove("final-verdict-safe", "final-verdict-unsafe");

  if (isUnsafe) {
    classificationBadge.classList.add("badge-unsafe");
    classificationBadge.textContent = "⚠️ THREAT SIGNAL IDENTIFIED";

    finalVerdict.classList.add("final-verdict-unsafe");
    const intro = "⚠️ Threat Signal Identified.";

    const explanationSegments = [];
    if (riskPercent >= 70) {
      explanationSegments.push(
        "Multiple high‑risk signals were detected across sender identity, content wording, and technical indicators."
      );
    } else {
      explanationSegments.push(
        "One or more indicators suggest this message may be part of a social‑engineering or phishing attempt."
      );
    }

    if (linkResult.urls.length) {
      explanationSegments.push(
        "Review all links by hovering to confirm the true destination before clicking, and open them only in a hardened browser session if absolutely required."
      );
    }

    if (inputs.attachments) {
      explanationSegments.push(
        "Treat attachments as untrusted code; scan them with endpoint protection before opening and avoid enabling any document macros."
      );
    }

    explanationSegments.push(
      "When in doubt, validate the request through a known‑good channel (official website, phone number on your card, or your IT/security team) instead of replying or interacting directly."
    );

    finalVerdict.textContent = `${intro} ${explanationSegments.join(" ")}`;
  } else {
    classificationBadge.classList.add("badge-safe");
    classificationBadge.textContent = "✅ SECURE TRANSMISSION DETECTED";

    finalVerdict.classList.add("final-verdict-safe");

    const intro = "✅ Secure Transmission Detected.";

    const explanationSegments = [
      "No strong phishing patterns, high‑risk language, or clearly suspicious technical indicators were identified in this message.",
    ];

    if (riskPercent > 25) {
      explanationSegments.push(
        "However, minor risk factors are present, so apply normal professional caution and confirm any sensitive requests through your usual business processes."
      );
    } else {
      explanationSegments.push(
        "Content, tone, and structure are consistent with a legitimate business or personal email, though basic caution should always be maintained."
      );
    }

    finalVerdict.textContent = `${intro} ${explanationSegments.join(" ")}`;
  }
}

function runAnalysis() {
  const analysis = aggregateAnalysis();
  renderThreats(analysis.threats);
  renderKeywords(analysis.keywordResult);
  renderVerdict(analysis);
}

function clearAll() {
  rawEmailInput.value = "";

  classificationBadge.className = "badge badge-idle";
  classificationBadge.textContent = "SYSTEM IDLE – NO PACKET LOADED";

  scoreBar.style.width = "0%";
  scoreValue.textContent = "–";

  threatList.innerHTML = "";
  const li = document.createElement("li");
  li.className = "threat-item";
  li.innerHTML =
    '<div class="threat-indicator threat-indicator--safe"></div><div>Awaiting inbound packet for analysis.</div>';
  threatList.appendChild(li);

  keywordSummary.textContent =
    "No telemetry. Load an email to inspect linguistic patterns.";

  finalVerdict.classList.remove("final-verdict-safe", "final-verdict-unsafe");
  finalVerdict.textContent =
    "Feed an email into the analyzer to receive a classification.";

  timestampLabel.textContent = "Awaiting packet…";
}

analyzeBtn.addEventListener("click", runAnalysis);
clearBtn.addEventListener("click", clearAll);

document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "enter") {
    e.preventDefault();
    runAnalysis();
  }
});

clearAll();

