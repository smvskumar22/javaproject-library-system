import re
import time
from textwrap import dedent

import pandas as pd
import streamlit as st


# ---------- Theming / Layout ----------

st.set_page_config(
    page_title="Cyber Ops – Email Threat Analyzer",
    page_icon="🛡️",
    layout="wide",
)

CYBER_CSS = """
<style>
/* Page base */
body {
    background-color: #0a0a0a !important;
    color: #39FF14 !important;
    font-family: "Fira Code", "Source Code Pro", Menlo, Monaco, Consolas, monospace;
}

/* Main app container */
.block-container {
    padding-top: 1.5rem;
    padding-bottom: 2.5rem;
}

/* Headings */
h1, h2, h3, h4, h5, h6 {
    color: #39FF14 !important;
    letter-spacing: 0.08em;
}

/* Text area styling */
textarea {
    background: radial-gradient(circle at top left, #111111, #050505) !important;
    color: #39FF14 !important;
    border-radius: 8px !important;
    border: 1px solid rgba(57, 255, 20, 0.5) !important;
    box-shadow: 0 0 18px rgba(57, 255, 20, 0.25);
    font-family: "Fira Code", monospace !important;
}

/* Buttons */
.stButton>button {
    background: linear-gradient(90deg, #39FF14, #1affd5);
    color: #000000;
    border-radius: 999px;
    border: 1px solid #39FF14;
    box-shadow: 0 0 20px rgba(57, 255, 20, 0.65);
    text-transform: uppercase;
    letter-spacing: 0.16em;
    font-weight: 600;
}
.stButton>button:hover {
    box-shadow: 0 0 30px rgba(57, 255, 20, 0.9);
}

/* Threat level box */
.threat-box {
    border-radius: 10px;
    padding: 1rem 1.25rem;
    border: 1px solid rgba(57, 255, 20, 0.4);
    box-shadow: 0 0 22px rgba(57, 255, 20, 0.35);
    background: radial-gradient(circle at top left, #111111, #030303);
    font-family: "Fira Code", monospace;
}
.threat-box-high {
    border-color: #ff3366;
    box-shadow: 0 0 28px rgba(255, 51, 102, 0.75);
}
.threat-box-medium {
    border-color: #ffb638;
    box-shadow: 0 0 24px rgba(255, 182, 56, 0.65);
}
.threat-box-low {
    border-color: #39FF14;
}

/* DataFrame table tweaks */
.dataframe td, .dataframe th {
    color: #e6ffe1 !important;
    background-color: #060606 !important;
    border-color: #202020 !important;
}

/* Subtle grid overlay */
[data-testid="stAppViewContainer"]::before {
    content: "";
    position: fixed;
    inset: 0;
    background-image:
        linear-gradient(#111111 1px, transparent 1px),
        linear-gradient(90deg, #111111 1px, transparent 1px);
    background-size: 40px 40px;
    opacity: 0.18;
    pointer-events: none;
    z-index: -1;
}
</style>
"""
st.markdown(CYBER_CSS, unsafe_allow_html=True)

st.title("CYBER OPS // EMAIL PHISHING & THREAT ANALYZER")
st.caption("Inline heuristics engine for raw email headers and content. No data leaves your machine.")


# ---------- Analysis helpers ----------

SUSPICIOUS_TLDS = {".xyz", ".top", ".click", ".club", ".live", ".link"}
URGENCY_KEYWORDS = [
    "action required",
    "suspicious activity",
    "verify now",
    "verify your account",
    "immediate attention",
    "urgent",
    "final notice",
    "account locked",
]

URL_REGEX = re.compile(
    r"https?://[^\s)<>\"']+",
    re.IGNORECASE,
)

IP_URL_REGEX = re.compile(
    r"https?://\d{1,3}(?:\.\d{1,3}){3}",
    re.IGNORECASE,
)


def extract_headers_and_body(raw: str):
    """Split raw email into unfolded headers and body."""
    if not raw:
        return "", ""

    # Normalise newlines and split at first blank line.
    normalized = raw.replace("\r\n", "\n")
    parts = normalized.split("\n\n", 1)
    headers_block = parts[0] if parts else ""
    body = parts[1] if len(parts) > 1 else ""

    # Unfold header continuations (lines starting with space or tab).
    unfolded = re.sub(r"\n[ \t]+", " ", headers_block)
    return unfolded, body


def parse_header_value(headers: str, name: str) -> str:
    m = re.search(rf"^{name}:\s*(.+)$", headers, flags=re.IGNORECASE | re.MULTILINE)
    return m.group(1).strip() if m else ""


def extract_domain(email: str) -> str:
    if not email or "@" not in email:
        return ""
    return email.split("@", 1)[1].strip().lower()


def analyze_urls(text: str):
    urls = list(set(URL_REGEX.findall(text or "")))
    risks = []

    for url in urls:
        is_ip = bool(IP_URL_REGEX.match(url))
        tld = ""
        m = re.search(r"\.([a-z]{2,})(?:[/:]|$)", url.split("?")[0], flags=re.IGNORECASE)
        if m:
            tld = "." + m.group(1).lower()

        if is_ip:
            risks.append(
                {
                    "Category": "URL",
                    "Detail": f"Link points directly to IP address: {url}",
                    "Severity": "High",
                }
            )
        elif tld in SUSPICIOUS_TLDS:
            risks.append(
                {
                    "Category": "URL",
                    "Detail": f"Suspicious top-level domain ({tld}) in link: {url}",
                    "Severity": "Medium",
                }
            )

    return urls, risks


def analyze_urgency(text: str):
    text_lc = (text or "").lower()
    hits = []
    for kw in URGENCY_KEYWORDS:
        if kw in text_lc:
            hits.append(kw)

    risks = []
    if hits:
        risks.append(
            {
                "Category": "Language",
                "Detail": "Urgency phrasing detected: " + ", ".join(sorted(set(hits))),
                "Severity": "Medium",
            }
        )
    return hits, risks


def analyze_sender_mismatch(headers: str):
    from_val = parse_header_value(headers, "From")
    reply_to = parse_header_value(headers, "Reply-To")
    return_path = parse_header_value(headers, "Return-Path")

    # Extract bare email addresses if wrapped in display names / angle brackets
    def extract_email(v: str) -> str:
        if not v:
            return ""
        m = re.search(r"<([^>]+)>", v)
        if m:
            return m.group(1).strip()
        m = re.search(r"([a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})", v, flags=re.I)
        return m.group(1).strip() if m else ""

    from_email = extract_email(from_val)
    reply_email = extract_email(reply_to)
    return_email = extract_email(return_path)

    base_domain = extract_domain(from_email)
    reply_domain = extract_domain(reply_email)
    return_domain = extract_domain(return_email)

    risks = []

    if base_domain and reply_domain and base_domain != reply_domain:
        risks.append(
            {
                "Category": "Sender",
                "Detail": f"'From' domain ({base_domain}) differs from 'Reply-To' domain ({reply_domain}).",
                "Severity": "High",
            }
        )

    if base_domain and return_domain and base_domain != return_domain:
        risks.append(
            {
                "Category": "Sender",
                "Detail": f"'From' domain ({base_domain}) differs from 'Return-Path' domain ({return_domain}).",
                "Severity": "High",
            }
        )

    # Very generic free-mail + corporate looking display name
    if from_val and base_domain.endswith(("gmail.com", "outlook.com", "yahoo.com")):
        if any(x in from_val.lower() for x in ["support", "billing", "security", "bank"]):
            risks.append(
                {
                    "Category": "Sender",
                    "Detail": "Generic free-mail address used with an official-sounding display name.",
                    "Severity": "Medium",
                }
            )

    return {
        "from": from_val,
        "reply_to": reply_to,
        "return_path": return_path,
        "base_domain": base_domain,
        "reply_domain": reply_domain,
        "return_domain": return_domain,
    }, risks


def compute_threat_level(risks):
    """Convert risk items into a score and label."""
    if not risks:
        return 10, "Low"

    score = 0
    for r in risks:
        sev = r.get("Severity", "").lower()
        if sev == "high":
            score += 30
        elif sev == "medium":
            score += 15
        else:
            score += 5

    # Clamp score
    score = max(0, min(score, 100))

    if score >= 70:
        label = "Critical"
    elif score >= 45:
        label = "High"
    elif score >= 25:
        label = "Medium"
    else:
        label = "Low"

    return score, label


# ---------- UI ----------

raw_email = st.text_area(
    "RAW EMAIL INPUT",
    placeholder=(
        "Paste full raw email (headers + body) here.\n"
        "Example: From:, To:, Subject:, Received:… then the HTML/plain-text body."
    ),
    height=260,
)

col_left, col_right = st.columns([1, 1])

with col_left:
    scan_btn = st.button("INITIATE CYBER SCAN", type="primary", use_container_width=True)

with col_right:
    st.markdown(
        dedent(
            """
            _Hint_: For best results, paste the output from  
            **“View original / View source / Show raw message”** in your email client.
            """
        )
    )

st.markdown("---")

if scan_btn and raw_email.strip():
    with st.status("Booting deep scan pipeline…", expanded=True) as status:
        status.update(label="Phase 1 – Parsing headers & body…")
        time.sleep(0.7)
        headers, body = extract_headers_and_body(raw_email)

        status.update(label="Phase 2 – Inspecting URLs & routes…")
        time.sleep(0.7)
        urls, url_risks = analyze_urls(raw_email)

        status.update(label="Phase 3 – Evaluating language & social engineering cues…")
        time.sleep(0.7)
        urgency_hits, lang_risks = analyze_urgency(raw_email)

        status.update(label="Phase 4 – Verifying sender integrity…")
        time.sleep(0.7)
        sender_meta, sender_risks = analyze_sender_mismatch(headers)

        all_risks = url_risks + lang_risks + sender_risks
        threat_score, threat_label = compute_threat_level(all_risks)

        status.update(label="Scan complete – report ready.", state="complete")
        time.sleep(0.4)

    # ---------- Index View / Threat Meter ----------

    meter_col, info_col = st.columns([1, 2])

    with meter_col:
        st.subheader("Threat Level")
        # Map label to color / box class and “safe / warning”
        if threat_score <= 20:
            box_class = "threat-box threat-box-low"
            verdict = "SAFE"
            msg = "✅ Secure Transmission Detected."
        elif threat_score <= 45:
            box_class = "threat-box threat-box-medium"
            verdict = "WARNING"
            msg = "⚠️ Elevated Risk – Review Carefully."
        else:
            box_class = "threat-box threat-box-high"
            verdict = "WARNING"
            msg = "⚠️ Threat Signal Identified."

        st.markdown(
            f"""
            <div class="{box_class}">
              <div><strong>Threat Level:</strong> {threat_label}</div>
              <div><strong>Risk Score:</strong> {threat_score:.0f} / 100</div>
              <div><strong>Verdict:</strong> {verdict}</div>
              <div style="margin-top: 0.5rem;">{msg}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.progress(threat_score / 100.0)

    with info_col:
        st.subheader("Header Snapshot")
        st.code(
            "\n".join(
                line
                for line in [
                    f"From:        {sender_meta.get('from') or '—'}",
                    f"Reply-To:    {sender_meta.get('reply_to') or '—'}",
                    f"Return-Path: {sender_meta.get('return_path') or '—'}",
                ]
            ),
            language="text",
        )

        if urls:
            st.markdown("**Detected URLs**")
            for u in urls:
                st.markdown(f"- `{u}`")
        else:
            st.markdown("**Detected URLs**: _None found in payload._")

    # ---------- Security Report Table ----------

    st.subheader("Security Report")

    if all_risks:
        df = pd.DataFrame(all_risks)
        st.dataframe(df, use_container_width=True)
    else:
        st.markdown(
            "> No explicit technical or linguistic risk indicators were detected. "
            "Apply normal organizational security hygiene and validate any unusual requests out-of-band."
        )

else:
    st.info("Paste a raw email and click **INITIATE CYBER SCAN** to generate a threat report.")