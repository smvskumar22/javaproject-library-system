# Neon Sentinel – Email Threat Analyzer

Neon Sentinel is a **cyberpunk‑styled, client‑side email analyzer** that helps you quickly assess whether an email looks **SAFE** or **UNSAFE** based on common phishing and social‑engineering signals.

## How to run

You can open `index.html` directly in a modern browser, or run a tiny static server:

```bash
npm install
npm run start
```

Then open the printed URL (usually `http://localhost:3000` or `http://localhost:5000`) in your browser.

## Using the analyzer

1. **Sender address** – paste the actual `From:` email address.
2. **Display name** – paste the human‑readable name shown in the mail client.
3. **Subject line** – copy the email subject.
4. **Attachments** – list filenames separated by commas (e.g. `invoice.zip, reset.docm`).
5. **Payload body** – paste the full email text, including links.
6. Click **“INITIATE THREAT SCAN”** (or press `Ctrl+Enter`) to analyze.

The analyzer will:

- Classify the email as **SAFE** or **UNSAFE**.
- Show **“✅ Secure Transmission Detected.”** for safe emails.
- Show **“⚠️ Threat Signal Identified.”** for unsafe emails.
- Provide a **0–100 safety confidence score**.
- List **threat vectors** (links, attachments, sender oddities).
- Highlight **suspicious keywords** (urgent, password, lottery, etc.).
- Give a **short professional explanation** of why the email was classified that way.

> This tool is heuristic and should **augment, not replace, professional judgment and your organization’s security policies**.

